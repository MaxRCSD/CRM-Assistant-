import {
  customers, type Customer, type InsertCustomer,
  orders, type Order, type InsertOrder,
  productPreferences, type ProductPreference, type InsertProductPreference,
  topProducts, type TopProduct, type InsertTopProduct,
  notes, type Note, type InsertNote,
  purchaseTrends, type PurchaseTrend, type InsertPurchaseTrend,
  recommendedActions, type RecommendedAction, type InsertRecommendedAction,
  users, type User, type InsertUser
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Customer operations
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  getCustomerByEmail(email: string): Promise<Customer | undefined>;
  searchCustomers(query: string): Promise<Customer[]>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;

  // Order operations
  getOrders(customerId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;

  // Product preference operations
  getProductPreferences(customerId: number): Promise<ProductPreference[]>;
  createProductPreference(preference: InsertProductPreference): Promise<ProductPreference>;

  // Top product operations
  getTopProducts(customerId: number): Promise<TopProduct[]>;
  createTopProduct(product: InsertTopProduct): Promise<TopProduct>;

  // Note operations
  getNotes(customerId: number): Promise<Note[]>;
  createNote(note: InsertNote): Promise<Note>;

  // Purchase trend operations
  getPurchaseTrends(customerId: number): Promise<PurchaseTrend[]>;
  createPurchaseTrend(trend: InsertPurchaseTrend): Promise<PurchaseTrend>;

  // Recommended action operations
  getRecommendedActions(customerId: number): Promise<RecommendedAction[]>;
  createRecommendedAction(action: InsertRecommendedAction): Promise<RecommendedAction>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private customers: Map<number, Customer>;
  private orders: Map<number, Order[]>;
  private productPreferences: Map<number, ProductPreference[]>;
  private topProducts: Map<number, TopProduct[]>;
  private notes: Map<number, Note[]>;
  private purchaseTrends: Map<number, PurchaseTrend[]>;
  private recommendedActions: Map<number, RecommendedAction[]>;
  
  private userCurrentId: number;
  private customerCurrentId: number;
  private orderCurrentId: number;
  private preferenceCurrentId: number;
  private topProductCurrentId: number;
  private noteCurrentId: number;
  private trendCurrentId: number;
  private actionCurrentId: number;

  constructor() {
    this.users = new Map();
    this.customers = new Map();
    this.orders = new Map();
    this.productPreferences = new Map();
    this.topProducts = new Map();
    this.notes = new Map();
    this.purchaseTrends = new Map();
    this.recommendedActions = new Map();
    
    this.userCurrentId = 1;
    this.customerCurrentId = 1;
    this.orderCurrentId = 1;
    this.preferenceCurrentId = 1;
    this.topProductCurrentId = 1;
    this.noteCurrentId = 1;
    this.trendCurrentId = 1;
    this.actionCurrentId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Customer operations
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async getCustomerByEmail(email: string): Promise<Customer | undefined> {
    return Array.from(this.customers.values()).find(
      (customer) => customer.email === email,
    );
  }

  async searchCustomers(query: string): Promise<Customer[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.customers.values()).filter(
      (customer) => 
        customer.name.toLowerCase().includes(lowercaseQuery) ||
        customer.email.toLowerCase().includes(lowercaseQuery)
    );
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.customerCurrentId++;
    const customer: Customer = { ...insertCustomer, id };
    this.customers.set(id, customer);
    return customer;
  }

  // Order operations
  async getOrders(customerId: number): Promise<Order[]> {
    return this.orders.get(customerId) || [];
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderCurrentId++;
    const order: Order = { ...insertOrder, id };
    
    const customerOrders = this.orders.get(order.customerId) || [];
    customerOrders.push(order);
    this.orders.set(order.customerId, customerOrders);
    
    // Update customer metrics
    const customer = this.customers.get(order.customerId);
    if (customer) {
      customer.orderCount += 1;
      customer.lastOrderDate = order.date;
      
      // Calculate new lifetime value
      const totalOrders = customerOrders.reduce((sum, o) => sum + o.amount, 0);
      customer.lifetimeValue = totalOrders;
      
      // Calculate new average order value
      customer.averageOrderValue = totalOrders / customerOrders.length;
      
      this.customers.set(customer.id, customer);
    }
    
    return order;
  }

  // Product preference operations
  async getProductPreferences(customerId: number): Promise<ProductPreference[]> {
    return this.productPreferences.get(customerId) || [];
  }

  async createProductPreference(insertPreference: InsertProductPreference): Promise<ProductPreference> {
    const id = this.preferenceCurrentId++;
    const preference: ProductPreference = { ...insertPreference, id };
    
    const customerPreferences = this.productPreferences.get(preference.customerId) || [];
    customerPreferences.push(preference);
    this.productPreferences.set(preference.customerId, customerPreferences);
    
    return preference;
  }

  // Top product operations
  async getTopProducts(customerId: number): Promise<TopProduct[]> {
    return this.topProducts.get(customerId) || [];
  }

  async createTopProduct(insertProduct: InsertTopProduct): Promise<TopProduct> {
    const id = this.topProductCurrentId++;
    const product: TopProduct = { ...insertProduct, id };
    
    const customerProducts = this.topProducts.get(product.customerId) || [];
    customerProducts.push(product);
    this.topProducts.set(product.customerId, customerProducts);
    
    return product;
  }

  // Note operations
  async getNotes(customerId: number): Promise<Note[]> {
    return this.notes.get(customerId) || [];
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const id = this.noteCurrentId++;
    const note: Note = { ...insertNote, id };
    
    const customerNotes = this.notes.get(note.customerId) || [];
    customerNotes.push(note);
    this.notes.set(note.customerId, customerNotes);
    
    return note;
  }

  // Purchase trend operations
  async getPurchaseTrends(customerId: number): Promise<PurchaseTrend[]> {
    return this.purchaseTrends.get(customerId) || [];
  }

  async createPurchaseTrend(insertTrend: InsertPurchaseTrend): Promise<PurchaseTrend> {
    const id = this.trendCurrentId++;
    const trend: PurchaseTrend = { ...insertTrend, id };
    
    const customerTrends = this.purchaseTrends.get(trend.customerId) || [];
    customerTrends.push(trend);
    this.purchaseTrends.set(trend.customerId, customerTrends);
    
    return trend;
  }

  // Recommended action operations
  async getRecommendedActions(customerId: number): Promise<RecommendedAction[]> {
    return this.recommendedActions.get(customerId) || [];
  }

  async createRecommendedAction(insertAction: InsertRecommendedAction): Promise<RecommendedAction> {
    const id = this.actionCurrentId++;
    const action: RecommendedAction = { ...insertAction, id };
    
    const customerActions = this.recommendedActions.get(action.customerId) || [];
    customerActions.push(action);
    this.recommendedActions.set(action.customerId, customerActions);
    
    return action;
  }

  // Initialize with sample data
  private initializeSampleData() {
    // Create sample staff user
    this.createUser({
      username: "staff",
      password: "password123",
      fullName: "John Smith",
      role: "staff",
      avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    });

    // Create sample customers
    const customerData = [
      {
        name: "Sarah Johnson",
        email: "sarah.j@example.com",
        phone: "(555) 111-2222",
        segment: "Regular",
        customerSince: new Date("2020-05-15"),
        lifetimeValue: 4850.75,
        orderCount: 18,
        lastOrderDate: new Date("2023-06-02"),
        averageOrderValue: 269.49
      },
      {
        name: "Michael Chen",
        email: "mchen@example.com",
        phone: "(555) 123-4567",
        segment: "Premium",
        customerSince: new Date("2019-10-08"),
        lifetimeValue: 8245.50,
        orderCount: 32,
        lastOrderDate: new Date("2023-05-12"),
        averageOrderValue: 257.67
      },
      {
        name: "Emma Rodriguez",
        email: "emma.r@example.com",
        phone: "(555) 333-4444",
        segment: "Premium",
        customerSince: new Date("2021-01-22"),
        lifetimeValue: 5120.25,
        orderCount: 14,
        lastOrderDate: new Date("2023-05-28"),
        averageOrderValue: 365.73
      },
      {
        name: "David Wilson",
        email: "dwilson@example.com",
        phone: "(555) 555-6666",
        segment: "Regular",
        customerSince: new Date("2018-08-14"),
        lifetimeValue: 12450.80,
        orderCount: 48,
        lastOrderDate: new Date("2023-06-10"),
        averageOrderValue: 259.39
      },
      {
        name: "Olivia Taylor",
        email: "o.taylor@example.com",
        phone: "(555) 777-8888",
        segment: "VIP",
        customerSince: new Date("2020-03-30"),
        lifetimeValue: 15780.45,
        orderCount: 27,
        lastOrderDate: new Date("2023-06-15"),
        averageOrderValue: 584.46
      }
    ];

    customerData.forEach(async (data) => {
      const customer = await this.createCustomer(data);
      this.createSampleDataForCustomer(customer.id);
    });
  }

  private createSampleDataForCustomer(customerId: number) {
    // Create sample orders
    const orderData = [
      {
        customerId,
        date: new Date("2023-05-12"),
        amount: 345.99,
        itemCount: 3,
        status: "completed",
        vehicleSize: "Medium Van",
        mileage: 48,
        handballing: 30,
        waitingTime: 15
      },
      {
        customerId,
        date: new Date("2023-04-03"),
        amount: 129.50,
        itemCount: 1,
        status: "completed",
        vehicleSize: "Small Van",
        mileage: 25,
        handballing: 0,
        waitingTime: 0
      },
      {
        customerId,
        date: new Date("2023-03-15"),
        amount: 278.25,
        itemCount: 2,
        status: "completed",
        vehicleSize: "Medium Van",
        mileage: 35,
        handballing: 15,
        waitingTime: 0
      },
      {
        customerId,
        date: new Date("2023-02-08"),
        amount: 412.75,
        itemCount: 4,
        status: "completed",
        vehicleSize: "Large Van",
        mileage: 62,
        handballing: 45,
        waitingTime: 30
      }
    ];

    orderData.forEach(data => this.createOrder(data));

    // Create sample product preferences
    const preferenceData = [
      {
        customerId,
        category: "Electronics",
        percentage: 65
      },
      {
        customerId,
        category: "Home Goods",
        percentage: 20
      },
      {
        customerId,
        category: "Accessories",
        percentage: 15
      }
    ];

    preferenceData.forEach(data => this.createProductPreference(data));

    // Create sample top products
    const topProductData = [
      {
        customerId,
        name: "Premium Wireless Headphones"
      },
      {
        customerId,
        name: "Smart Home Hub"
      },
      {
        customerId,
        name: "USB-C Fast Charging Cable"
      }
    ];

    topProductData.forEach(data => this.createTopProduct(data));

    // Create sample notes
    const noteData = [
      {
        customerId,
        author: "Alex Thompson",
        date: new Date("2023-05-15"),
        type: "Support",
        content: "Customer called about upgrading their current device. Prefers to wait for the new model coming in September. Set a reminder to follow up."
      },
      {
        customerId,
        author: "Jamie Rodriguez",
        date: new Date("2023-04-03"),
        type: "Sales",
        content: "Discussed bundle offer for home office equipment. Customer is interested but wanted to think about it. Will follow up next week."
      }
    ];

    noteData.forEach(data => this.createNote(data));

    // Create sample purchase trends
    const trendData = [
      {
        customerId,
        month: "Jan",
        amount: 540
      },
      {
        customerId,
        month: "Feb",
        amount: 320
      },
      {
        customerId,
        month: "Mar",
        amount: 580
      },
      {
        customerId,
        month: "Apr",
        amount: 420
      },
      {
        customerId,
        month: "May",
        amount: 610
      },
      {
        customerId,
        month: "Jun",
        amount: 780
      }
    ];

    trendData.forEach(data => this.createPurchaseTrend(data));

    // Create sample recommended actions
    const actionData = [
      {
        customerId,
        title: "Loyalty Program Upgrade",
        description: "Customer eligible for Gold status",
        type: "loyalty",
        icon: "thumbs-up"
      },
      {
        customerId,
        title: "Product Recommendation",
        description: "Smart home accessories bundle",
        type: "product",
        icon: "shopping-bag"
      },
      {
        customerId,
        title: "Follow-up Call",
        description: "Scheduled for next week",
        type: "call",
        icon: "megaphone"
      },
      // Courier-specific recommendations
      {
        customerId,
        title: "Handballing Service",
        description: "Book 30 mins of handballing for this delivery at 15% discount",
        type: "handballing",
        icon: "users"
      },
      {
        customerId,
        title: "Flexible Waiting Time",
        description: "Add 20 mins waiting time to your delivery at 10% off standard rate",
        type: "waiting",
        icon: "clock"
      },
      {
        customerId,
        title: "Vehicle Upgrade",
        description: "Consider Large Van for your next bulky delivery",
        type: "vehicle",
        icon: "truck"
      }
    ];

    actionData.forEach(data => this.createRecommendedAction(data));
  }
}

export const storage = new MemStorage();
