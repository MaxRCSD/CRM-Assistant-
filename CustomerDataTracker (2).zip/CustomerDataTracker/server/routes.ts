import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertNoteSchema,
  insertCustomerSchema,
  insertOrderSchema
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  
  // GET /api/customers - Get all customers
  app.get("/api/customers", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string | undefined;
      let customers;
      
      if (query && query.trim() !== "") {
        customers = await storage.searchCustomers(query);
      } else {
        customers = await storage.getCustomers();
      }
      
      res.json(customers);
    } catch (error) {
      console.error("Error fetching customers:", error);
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  // GET /api/customers/:id - Get customer by ID
  app.get("/api/customers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      res.json(customer);
    } catch (error) {
      console.error("Error fetching customer:", error);
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });
  
  // POST /api/customers - Create a new customer
  app.post("/api/customers", async (req: Request, res: Response) => {
    try {
      const customerData = insertCustomerSchema.parse(req.body);
      const newCustomer = await storage.createCustomer(customerData);
      res.status(201).json(newCustomer);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating customer:", error);
      res.status(500).json({ message: "Failed to create customer" });
    }
  });

  // GET /api/customers/:id/profile - Get full customer profile with all related data
  app.get("/api/customers/:id/profile", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const [
        orders,
        productPreferences,
        topProducts,
        notes,
        purchaseTrends,
        recommendedActions
      ] = await Promise.all([
        storage.getOrders(id),
        storage.getProductPreferences(id),
        storage.getTopProducts(id),
        storage.getNotes(id),
        storage.getPurchaseTrends(id),
        storage.getRecommendedActions(id)
      ]);
      
      res.json({
        customer,
        orders,
        productPreferences,
        topProducts,
        notes,
        purchaseTrends,
        recommendedActions
      });
    } catch (error) {
      console.error("Error fetching customer profile:", error);
      res.status(500).json({ message: "Failed to fetch customer profile" });
    }
  });

  // GET /api/customers/:id/orders - Get orders for a customer
  app.get("/api/customers/:id/orders", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const orders = await storage.getOrders(id);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  // POST /api/customers/:id/orders - Create a new order for a customer
  app.post("/api/customers/:id/orders", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const orderData = insertOrderSchema.parse({
        ...req.body,
        customerId: id
      });
      
      const newOrder = await storage.createOrder(orderData);
      res.status(201).json(newOrder);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating order:", error);
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  // GET /api/customers/:id/product-preferences - Get product preferences for a customer
  app.get("/api/customers/:id/product-preferences", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const preferences = await storage.getProductPreferences(id);
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching product preferences:", error);
      res.status(500).json({ message: "Failed to fetch product preferences" });
    }
  });

  // GET /api/customers/:id/top-products - Get top products for a customer
  app.get("/api/customers/:id/top-products", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const products = await storage.getTopProducts(id);
      res.json(products);
    } catch (error) {
      console.error("Error fetching top products:", error);
      res.status(500).json({ message: "Failed to fetch top products" });
    }
  });

  // GET /api/customers/:id/notes - Get notes for a customer
  app.get("/api/customers/:id/notes", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const notes = await storage.getNotes(id);
      res.json(notes);
    } catch (error) {
      console.error("Error fetching notes:", error);
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });

  // POST /api/customers/:id/notes - Create a new note for a customer
  app.post("/api/customers/:id/notes", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const noteData = insertNoteSchema.parse({
        ...req.body,
        customerId: id,
        date: new Date()
      });
      
      const newNote = await storage.createNote(noteData);
      res.status(201).json(newNote);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating note:", error);
      res.status(500).json({ message: "Failed to create note" });
    }
  });

  // GET /api/customers/:id/purchase-trends - Get purchase trends for a customer
  app.get("/api/customers/:id/purchase-trends", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const trends = await storage.getPurchaseTrends(id);
      res.json(trends);
    } catch (error) {
      console.error("Error fetching purchase trends:", error);
      res.status(500).json({ message: "Failed to fetch purchase trends" });
    }
  });

  // GET /api/customers/:id/recommended-actions - Get recommended actions for a customer
  app.get("/api/customers/:id/recommended-actions", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }
      
      const customer = await storage.getCustomer(id);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      const actions = await storage.getRecommendedActions(id);
      res.json(actions);
    } catch (error) {
      console.error("Error fetching recommended actions:", error);
      res.status(500).json({ message: "Failed to fetch recommended actions" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
