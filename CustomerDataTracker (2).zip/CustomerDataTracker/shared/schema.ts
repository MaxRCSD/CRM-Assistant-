import { pgTable, text, serial, integer, timestamp, real, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  avatarUrl: text("avatar_url"),
  role: text("role").default("staff"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  avatarUrl: true,
  role: true,
});

// Customer schema
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  industry: text("industry").default("Retail"),
  segment: text("segment").default("Regular"),
  customerSince: timestamp("customer_since").notNull(),
  lifetimeValue: real("lifetime_value").notNull().default(0),
  orderCount: integer("order_count").notNull().default(0),
  lastOrderDate: timestamp("last_order_date"),
  averageOrderValue: real("average_order_value").notNull().default(0),
  wonOrderCount: integer("won_order_count").notNull().default(0),
  lostOrderCount: integer("lost_order_count").notNull().default(0),
  communicationPreference: text("communication_preference").default("Email"),
  accountType: text("account_type").default("Standard"),
  paymentMethod: text("payment_method").default("Invoice"),
});

export const insertCustomerSchema = createInsertSchema(customers).pick({
  name: true,
  email: true,
  phone: true,
  industry: true,
  segment: true,
  customerSince: true,
  lifetimeValue: true,
  orderCount: true,
  lastOrderDate: true,
  averageOrderValue: true,
  wonOrderCount: true,
  lostOrderCount: true,
  communicationPreference: true,
  accountType: true,
  paymentMethod: true,
});

// Order schema
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  date: timestamp("date").notNull(),
  amount: real("amount").notNull(),
  itemCount: integer("item_count").notNull(),
  status: text("status").notNull().default("completed"),
  vehicleSize: text("vehicle_size").default("Standard"),
  mileage: integer("mileage").default(0),
  handballing: integer("handballing").default(0),
  waitingTime: integer("waiting_time").default(0),
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  customerId: true,
  date: true,
  amount: true,
  itemCount: true,
  status: true,
  vehicleSize: true,
  mileage: true,
  handballing: true,
  waitingTime: true,
});

// Product preference schema
export const productPreferences = pgTable("product_preferences", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  category: text("category").notNull(),
  percentage: integer("percentage").notNull(),
});

export const insertProductPreferenceSchema = createInsertSchema(productPreferences).pick({
  customerId: true,
  category: true,
  percentage: true,
});

// Top products schema
export const topProducts = pgTable("top_products", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  name: text("name").notNull(),
});

export const insertTopProductSchema = createInsertSchema(topProducts).pick({
  customerId: true,
  name: true,
});

// Customer notes schema
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  author: text("author").notNull(),
  date: timestamp("date").notNull(),
  type: text("type").notNull(),
  content: text("content").notNull(),
});

export const insertNoteSchema = createInsertSchema(notes).pick({
  customerId: true,
  author: true,
  date: true,
  type: true,
  content: true,
});

// Purchase trends schema
export const purchaseTrends = pgTable("purchase_trends", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  month: text("month").notNull(),
  amount: real("amount").notNull(),
});

export const insertPurchaseTrendSchema = createInsertSchema(purchaseTrends).pick({
  customerId: true,
  month: true,
  amount: true,
});

// Recommended actions schema
export const recommendedActions = pgTable("recommended_actions", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(),
  icon: text("icon").notNull(),
});

export const insertRecommendedActionSchema = createInsertSchema(recommendedActions).pick({
  customerId: true,
  title: true,
  description: true,
  type: true,
  icon: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type ProductPreference = typeof productPreferences.$inferSelect;
export type InsertProductPreference = z.infer<typeof insertProductPreferenceSchema>;

export type TopProduct = typeof topProducts.$inferSelect;
export type InsertTopProduct = z.infer<typeof insertTopProductSchema>;

export type Note = typeof notes.$inferSelect;
export type InsertNote = z.infer<typeof insertNoteSchema>;

export type PurchaseTrend = typeof purchaseTrends.$inferSelect;
export type InsertPurchaseTrend = z.infer<typeof insertPurchaseTrendSchema>;

export type RecommendedAction = typeof recommendedActions.$inferSelect;
export type InsertRecommendedAction = z.infer<typeof insertRecommendedActionSchema>;
