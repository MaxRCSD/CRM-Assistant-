import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Customer, CustomerProfile as CustomerProfileType } from "@/types";
import { Button } from "@/components/ui/button";
import { LogOut, ArrowLeft } from "lucide-react";
import CustomerSidebar from "@/components/CustomerSidebar";
import CustomerHeader from "@/components/CustomerHeader";
import SummaryMetrics from "@/components/SummaryMetrics";
import PurchaseHistory from "@/components/PurchaseHistory";
import FrequentAddresses from "@/components/PurchaseTrends";
import CustomerNotes from "@/components/CustomerNotes";
import RecommendedActions from "@/components/RecommendedActions";
import AssistantInput from "@/components/AssistantInput";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function CustomerProfile() {
  const { id } = useParams();
  const customerId = parseInt(id || "0");
  const [, navigate] = useLocation();

  // Check if user is authenticated
  useEffect(() => {
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [navigate]);

  const { data, isLoading, error } = useQuery<CustomerProfileType>({
    queryKey: [`/api/customers/${customerId}/profile`],
    enabled: !isNaN(customerId) && customerId > 0
  });

  // Get all customers for the sidebar
  const { data: customers = [] } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    navigate('/login');
  };

  const handleBackToHome = () => {
    navigate('/portal');
  };

  if (isNaN(customerId)) {
    navigate('/portal');
    return null;
  }

  if (error) {
    return (
      <div className="bg-neutral-50 min-h-screen flex flex-col">
        <div className="bg-white shadow-sm border-b border-neutral-200">
          <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                onClick={handleBackToHome} 
                className="text-neutral-600"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <h1 className="text-2xl font-bold text-primary">CRM Assistant</h1>
            </div>
            <Button variant="ghost" onClick={handleLogout} className="text-neutral-600">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
        <div className="flex flex-1 overflow-hidden">
          <CustomerSidebar customers={customers} />
          <main className="flex-1 overflow-y-auto bg-neutral-50 flex flex-col items-center justify-center p-4">
            <Card className="max-w-md mx-auto">
              <CardContent className="pt-6">
                <h3 className="text-lg font-medium text-neutral-900">Error</h3>
                <p className="mt-2 text-neutral-600">
                  Failed to load customer profile. Please try again.
                </p>
                <Button onClick={handleBackToHome} className="mt-4">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Search
                </Button>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-neutral-50 min-h-screen flex flex-col">
      <div className="bg-white shadow-sm border-b border-neutral-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              onClick={handleBackToHome} 
              className="text-neutral-600"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <h1 className="text-2xl font-bold text-primary">CRM Assistant</h1>
          </div>
          <Button variant="ghost" onClick={handleLogout} className="text-neutral-600">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
      
      <div className="flex flex-1 overflow-hidden">
        <CustomerSidebar customers={customers} selectedId={customerId} />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 flex flex-col">
          <div className="flex-1 overflow-y-auto p-4">
            {isLoading ? (
              <div className="space-y-6">
                <Skeleton className="h-32 w-full rounded-lg" />
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Skeleton className="h-24 w-full rounded-lg" />
                  <Skeleton className="h-24 w-full rounded-lg" />
                  <Skeleton className="h-24 w-full rounded-lg" />
                  <Skeleton className="h-24 w-full rounded-lg" />
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Skeleton className="h-64 w-full rounded-lg" />
                  <Skeleton className="h-64 w-full rounded-lg" />
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Skeleton className="h-64 w-full rounded-lg" />
                  <Skeleton className="h-64 w-full rounded-lg" />
                </div>
                <Skeleton className="h-36 w-full rounded-lg" />
              </div>
            ) : data ? (
              <div className="space-y-6">
                <CustomerHeader customer={data.customer} />
                <SummaryMetrics customer={data.customer} />
                <PurchaseHistory orders={data.orders} />
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <FrequentAddresses orders={data.orders} />
                  <CustomerNotes notes={data.notes} customerId={customerId} />
                </div>
                
                <div className="grid grid-cols-1 gap-6">
                  <CustomerNotes 
                    notes={data.notes} 
                    customerId={customerId} 
                  />
                </div>
                
                <RecommendedActions actions={data.recommendedActions} />
              </div>
            ) : null}
          </div>
          
          <AssistantInput />
        </main>
      </div>
    </div>
  );
}
