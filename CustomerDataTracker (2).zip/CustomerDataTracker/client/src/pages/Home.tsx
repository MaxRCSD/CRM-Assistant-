import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Customer } from "@/types";
import Header from "@/components/Header";
import CustomerSidebar from "@/components/CustomerSidebar";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";

export default function Home() {
  const [, navigate] = useLocation();
  
  // Check if user is authenticated
  useEffect(() => {
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [navigate]);
  
  const { data: customers = [], isLoading } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  useEffect(() => {
    // Automatically redirect to the first customer if available
    if (customers.length > 0 && !isLoading) {
      navigate(`/customers/${customers[0].id}`);
    }
  }, [customers, isLoading, navigate]);
  
  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    navigate('/login');
  };

  return (
    <div className="bg-neutral-50 min-h-screen flex flex-col">
      <div className="bg-white shadow-sm border-b border-neutral-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary">CRM Assistant</h1>
          <Button variant="ghost" onClick={handleLogout} className="text-neutral-600">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
      
      <div className="flex flex-1 overflow-hidden">
        <CustomerSidebar customers={customers} isLoading={isLoading} />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 flex flex-col items-center justify-center p-4">
          <div className="text-center max-w-md mx-auto p-6 bg-white rounded-lg shadow-sm">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-12 w-12 mx-auto text-neutral-400" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" 
              />
            </svg>
            <h3 className="mt-4 text-lg font-medium text-neutral-900">
              {isLoading ? "Loading customers..." : "Please select a customer"}
            </h3>
            <p className="mt-2 text-neutral-600">
              {isLoading 
                ? "Fetching customer data..." 
                : "Select a customer from the sidebar to view their profile."
              }
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}
