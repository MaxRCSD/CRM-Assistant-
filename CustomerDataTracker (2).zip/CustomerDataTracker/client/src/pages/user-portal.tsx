import { useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth-context';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, LogOut } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

export default function UserPortal() {
  const [searchQuery, setSearchQuery] = useState('');
  const { logout } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchQuery.trim()) {
      toast({
        title: 'Search Error',
        description: 'Please enter a customer name or order number',
        variant: 'destructive'
      });
      return;
    }

    // Check if input is a 5-digit order number
    const isOrderNumber = /^\d{5}$/.test(searchQuery.trim());
    
    if (isOrderNumber) {
      navigate(`/orders/${searchQuery.trim()}`);
    } else {
      // Search for customer by name
      navigate(`/customers/1`); // For demo, navigating to customer #1
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-neutral-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary">CRM Assistant</h1>
          <Button variant="ghost" onClick={logout} className="text-neutral-600">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-2xl shadow-md">
          <CardContent className="p-6">
            <div className="space-y-6">
              <div className="text-center space-y-2">
                <h2 className="text-2xl font-bold text-neutral-900">Customer Lookup</h2>
                <p className="text-neutral-600">
                  Search for a customer by name or order number
                </p>
              </div>

              <form onSubmit={handleSearch} className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-5 w-5 text-neutral-400" />
                  <Input
                    className="pl-10 py-6 text-lg"
                    placeholder="Look up customer or Order number"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Button type="submit" className="w-full py-6 text-lg">
                  Search
                </Button>
              </form>

              <div className="text-center text-sm text-neutral-500">
                Find detailed customer information including order history,
                purchase trends, and recommended actions.
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-neutral-200 py-4">
        <div className="max-w-6xl mx-auto px-4 text-center text-neutral-500 text-sm">
          CRM Assistant for Collect Same Day Couriers &copy; {new Date().getFullYear()}
        </div>
      </footer>
    </div>
  );
}