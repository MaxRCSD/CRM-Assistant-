import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [, navigate] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    // Simple credential check
    if (username === 'user' && password === 'Slothtrot90') {
      localStorage.setItem('isAuthenticated', 'true');
      navigate('/portal');
    } else {
      setError('Invalid username or password');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-50">
      <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 gap-8 p-4">
        {/* Form section */}
        <Card className="w-full shadow-md">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">CRM Assistant</CardTitle>
            <CardDescription className="text-center">
              Enter your credentials to access the system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              {error && (
                <div className="text-red-500 text-sm">{error}</div>
              )}
            </form>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              onClick={handleSubmit} 
              disabled={isLoading || !username || !password}
            >
              {isLoading ? 'Logging in...' : 'Sign In'}
            </Button>
          </CardFooter>
        </Card>

        {/* Hero section */}
        <div className="hidden md:flex flex-col justify-center">
          <div className="space-y-4">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              Welcome to CRM Assistant
            </h1>
            <p className="text-lg text-neutral-600">
              The comprehensive customer lookup tool designed for Collect Same Day Couriers staff.
            </p>
            <ul className="space-y-2 text-neutral-600">
              <li className="flex items-center">
                <div className="mr-2 h-4 w-4 rounded-full bg-primary"></div>
                Quick access to customer profiles and order history
              </li>
              <li className="flex items-center">
                <div className="mr-2 h-4 w-4 rounded-full bg-primary"></div>
                View purchase trends and customer preferences
              </li>
              <li className="flex items-center">
                <div className="mr-2 h-4 w-4 rounded-full bg-primary"></div>
                Get personalized recommendations for each customer
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}