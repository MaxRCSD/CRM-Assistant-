export interface Customer {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  industry: string;
  segment: string;
  customerSince: string;
  lifetimeValue: number;
  orderCount: number;
  lastOrderDate: string | null;
  averageOrderValue: number;
  wonOrderCount: number;
  lostOrderCount: number;
  communicationPreference: string;
  accountType: string;
  paymentMethod: string;
}

export interface DeliveryAddress {
  line1: string;
  line2?: string;
  city: string;
  postcode: string;
}

export interface Order {
  id: number;
  customerId: number;
  date: string;
  amount: number;
  itemCount: number;
  status: string;
  vehicleSize: string;
  mileage: number;
  handballing: number;
  waitingTime: number;
  deliveryAddress: DeliveryAddress;
}

export interface ProductPreference {
  id: number;
  customerId: number;
  category: string;
  percentage: number;
}

export interface TopProduct {
  id: number;
  customerId: number;
  name: string;
}

export interface Note {
  id: number;
  customerId: number;
  author: string;
  date: string;
  type: string;
  content: string;
}

export interface PurchaseTrend {
  id: number;
  customerId: number;
  month: string;
  amount: number;
}

export interface RecommendedAction {
  id: number;
  customerId: number;
  title: string;
  description: string;
  type: string;
  icon: string;
}

export interface CustomerProfile {
  customer: Customer;
  orders: Order[];
  productPreferences: ProductPreference[];
  topProducts: TopProduct[];
  notes: Note[];
  purchaseTrends: PurchaseTrend[];
  recommendedActions: RecommendedAction[];
}
