
import { Order } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface OrderTimelineProps {
  order: Order;
}

export default function OrderTimeline({ order }: OrderTimelineProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Order Timeline</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {order.timeline?.map((event, index) => (
            <div key={index} className="flex items-start">
              <div className="min-w-24 text-sm text-neutral-500">
                {event.time}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-neutral-900">{event.status}</p>
                <p className="text-sm text-neutral-600">{event.description}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
