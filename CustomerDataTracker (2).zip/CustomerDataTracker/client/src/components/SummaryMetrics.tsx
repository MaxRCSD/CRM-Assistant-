import { Customer } from "@/types";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowUpRight } from "lucide-react";

interface SummaryMetricsProps {
  customer: Customer;
}

export default function SummaryMetrics({ customer }: SummaryMetricsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <Card className="md:col-span-2 lg:col-span-3">
        <CardContent className="p-5">
          <h3 className="text-sm font-medium text-neutral-500">Vehicle History</h3>
          <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <span className="text-lg font-semibold text-neutral-900">
                Last Vehicle: {customer.lastOrderSize || 'N/A'}
              </span>
              <div className="text-sm text-neutral-600">
                Mileage: {customer.lastOrderMileage || 'N/A'} miles
              </div>
            </div>
            <div>
              <span className="text-lg font-semibold text-neutral-900">
                Most Used: {customer.mostUsedVehicle || 'N/A'}
              </span>
              <div className="text-sm text-neutral-600">
                Avg Mileage: {customer.avgMileage || 'N/A'} miles/trip
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-5">
          <h3 className="text-sm font-medium text-neutral-500">Success Rate</h3>
          <div className="mt-2">
            <div className="text-xl font-semibold text-neutral-900">
              {customer.wonOrderCount > 0 
                ? Math.round((customer.wonOrderCount / (customer.wonOrderCount + customer.lostOrderCount)) * 100) 
                : 0}% Success
            </div>
            <div className="mt-1 text-sm">
              <span className="text-green-600">{customer.wonOrderCount} won</span>
              {' / '}
              <span className="text-red-600">{customer.lostOrderCount} lost</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-5">
          <h3 className="text-sm font-medium text-neutral-500">Lifetime Value</h3>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-xl font-semibold text-neutral-900 truncate">
              {formatCurrency(customer.lifetimeValue)}
            </span>
            <span className="text-sm font-medium text-neutral-600">
              {formatCurrency(customer.lifetimeValue / 12)} /mo
            </span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-5">
          <h3 className="text-sm font-medium text-neutral-500">Orders</h3>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-xl font-semibold text-neutral-900">
              {customer.orderCount}
            </span>
            <span className="text-xs text-neutral-500">total</span>
          </div>
          <div className="mt-1 text-xs whitespace-nowrap overflow-hidden">
            <span className="text-green-600">{customer.wonOrderCount} won</span>
            {' / '}
            <span className="text-red-600">{customer.lostOrderCount} lost</span>
            {' - '}
            <span className="font-medium">
              {customer.wonOrderCount > 0 
                ? Math.round((customer.wonOrderCount / (customer.wonOrderCount + customer.lostOrderCount)) * 100) 
                : 0}% win rate
            </span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-5">
          <h3 className="text-sm font-medium text-neutral-500">Last Order</h3>
          <div className="mt-1">
            <span className="text-2xl font-semibold text-neutral-900">
              {formatDate(customer.lastOrderDate)}
            </span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-5">
          <h3 className="text-sm font-medium text-neutral-500">Average Order Value</h3>
          <div className="mt-1 flex items-baseline">
            <span className="text-2xl font-semibold text-neutral-900">
              {formatCurrency(customer.averageOrderValue)}
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
