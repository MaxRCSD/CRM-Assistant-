import { useState } from "react";
import { Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function AssistantInput() {
  const [query, setQuery] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (query.trim() === "") return;
    
    // In a real implementation, this would send the query to a backend
    // that could process natural language and respond with relevant information
    toast({
      title: "Query Received",
      description: `Processing: "${query}"`,
    });
    
    setQuery("");
  };

  return (
    <div className="border-t border-neutral-200 bg-white p-4">
      <form onSubmit={handleSubmit} className="flex">
        <Input
          type="text"
          placeholder="Search for information or type a command..."
          className="flex-1 px-4 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-sm"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <Button 
          type="submit" 
          className="ml-2 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white"
        >
          <Send className="h-4 w-4" />
        </Button>
      </form>
      <div className="text-xs text-neutral-500 mt-2">
        Try: "Show purchase history" • "When was their last order?" • "What was their vehicle size?"
      </div>
    </div>
  );
}
