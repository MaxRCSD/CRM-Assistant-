
import { Order, DeliveryAddress } from "@/types";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";

interface FrequentAddressesProps {
  orders: Order[];
}

export default function FrequentAddresses({ orders }: FrequentAddressesProps) {
  // Process orders to get address frequency
  const addressMap = new Map<string, DeliveryAddress & { useCount: number }>();

  orders.forEach(order => {
    if (order.deliveryAddress) {
      const key = `${order.deliveryAddress.line1}-${order.deliveryAddress.postcode}`;
      const existing = addressMap.get(key);

      if (existing) {
        existing.useCount += 1;
      } else {
        addressMap.set(key, {
          ...order.deliveryAddress,
          useCount: 1
        });
      }
    }
  });

  // Convert to array and filter based on criteria
  const addresses = Array.from(addressMap.values());
  const frequentAddresses = addresses.filter(address => {
    const usagePercentage = (address.useCount / orders.length) * 100;
    return address.useCount >= 3 || usagePercentage >= 10;
  });

  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-900">Frequently Used Addresses</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {orders.length <= 2 || frequentAddresses.length === 0 ? (
            <div className="text-neutral-500">N/A</div>
          ) : (
            frequentAddresses.map((address, index) => (
              <div key={index} className="border-b border-neutral-100 last:border-0 pb-3 last:pb-0">
                <div className="text-sm font-medium text-neutral-900">
                  {address.line1}
                  {address.line2 && <span>, {address.line2}</span>}
                </div>
                <div className="text-sm text-neutral-600">
                  {address.city}, {address.postcode}
                </div>
                <div className="text-xs text-neutral-500 mt-1">
                  Used {address.useCount} times ({Math.round((address.useCount / orders.length) * 100)}% of orders)
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
