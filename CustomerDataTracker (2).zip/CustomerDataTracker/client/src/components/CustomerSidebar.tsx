import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Search, User, Users, BarChart2, Settings, Truck, AlertTriangle, FileText } from "lucide-react";
import { Customer } from "@/types";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { debounce } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";

interface CustomerSidebarProps {
  customers?: Customer[];
  selectedId?: number;
  isLoading?: boolean;
}

export default function CustomerSidebar({ 
  customers = [],
  selectedId,
  isLoading = false
}: CustomerSidebarProps) {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: filteredCustomers, refetch } = useQuery<Customer[]>({
    queryKey: ["/api/customers", { q: searchQuery }],
    enabled: searchQuery.length > 0,
  });

  const displayCustomers = searchQuery ? filteredCustomers || [] : customers;

  // Debounced search function
  const debouncedSearch = debounce((value: string) => {
    setSearchQuery(value);
  }, 300);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    debouncedSearch(e.target.value);
  };

  return (
    <aside className="bg-white w-64 border-r border-neutral-200 flex-shrink-0 hidden md:block overflow-y-auto">
      <div className="p-4">
        <div className="relative">
          <Input
            type="text"
            id="customer-search"
            placeholder="Search customers..."
            className="w-full px-4 py-2 pl-9 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-sm text-neutral-700 bg-neutral-50"
            onChange={handleSearch}
          />
          <Search className="h-4 w-4 text-neutral-400 absolute left-3 top-3" />
        </div>
      </div>

      <nav className="pt-2">
        <div className="px-4 py-2 text-sm font-medium text-neutral-500">RECENT CUSTOMERS</div>

        {isLoading ? (
          <div className="space-y-2 px-4">
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
          </div>
        ) : (
          displayCustomers.map((customer) => (
            <Link 
              key={customer.id} 
              href={`/customers/${customer.id}`}
              className={`block px-4 py-2 hover:bg-neutral-100 text-neutral-700 border-l-4 ${
                selectedId === customer.id ? 'border-primary' : 'border-transparent hover:border-primary'
              }`}
            >
              <div className="font-medium">{customer.name}</div>
              <div className="text-sm text-neutral-500">{customer.email}</div>
            </Link>
          ))
        )}

        {!isLoading && displayCustomers.length === 0 && (
          <div className="px-4 py-2 text-sm text-neutral-500">
            No customers found
          </div>
        )}

        <div className="mt-4 px-4 py-2 text-sm font-medium text-neutral-500">TOOLS AND GUIDANCE</div>
        <Link href="#" className="block px-4 py-2 hover:bg-neutral-100 text-neutral-700">
          <div className="flex items-center">
            <Truck className="h-4 w-4 mr-2" />
            <span>Light Haulage Vehicle Sizes</span>
          </div>
        </Link>
        <Link href="#" className="block px-4 py-2 hover:bg-neutral-100 text-neutral-700">
          <div className="flex items-center">
            <Truck className="h-4 w-4 mr-2" />
            <span>Heavy Goods Vehicle Sizes</span>
          </div>
        </Link>
        <Link href="#" className="block px-4 py-2 hover:bg-neutral-100 text-neutral-700">
          <div className="flex items-center">
            <AlertTriangle className="h-4 w-4 mr-2" />
            <span>ADR Guidance</span>
          </div>
        </Link>
        <Link href="#" className="block px-4 py-2 hover:bg-neutral-100 text-neutral-700">
          <div className="flex items-center">
            <FileText className="h-4 w-4 mr-2" />
            <span>Customs Guidance</span>
          </div>
        </Link>
      </nav>
    </aside>
  );
}