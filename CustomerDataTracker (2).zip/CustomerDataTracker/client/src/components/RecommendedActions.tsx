import { RecommendedAction } from "@/types";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  MessageSquare,
  Truck,
  Clock,
  Users2
} from "lucide-react";

interface RecommendedActionsProps {
  actions: RecommendedAction[];
}

export default function RecommendedActions({ actions }: RecommendedActionsProps) {
  const getIcon = (icon: string, type: string) => {
    switch (icon.toLowerCase()) {
      case 'truck':
        return (
          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center">
            <Truck className="h-6 w-6 text-emerald-600" />
          </div>
        );
      case 'clock':
        return (
          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center">
            <Clock className="h-6 w-6 text-amber-600" />
          </div>
        );
      case 'users':
        return (
          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
            <Users2 className="h-6 w-6 text-indigo-600" />
          </div>
        );
      default:
        return (
          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-neutral-100 flex items-center justify-center">
            <MessageSquare className="h-6 w-6 text-neutral-600" />
          </div>
        );
    }
  };

  // Group actions by type
  const courierServiceActions = actions.filter(action => 
    action.type === 'vehicle' || action.type === 'handballing' || action.type === 'waiting'
  );
  
  const generalActions = actions.filter(action => 
    action.type !== 'vehicle' && action.type !== 'handballing' && action.type !== 'waiting'
  );

  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-900">Recommended Actions</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {actions.length === 0 ? (
          <div className="text-center py-4 text-neutral-500">
            No recommended actions available
          </div>
        ) : (
          <>
            {courierServiceActions.length > 0 && (
              <div className="mb-6">
                <h3 className="text-md font-medium text-purple-700 mb-3 flex items-center">
                  <Truck className="h-4 w-4 mr-2" />
                  Suggest Pre-booking Services
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {courierServiceActions.map((action) => (
                    <div 
                      key={action.id} 
                      className="border border-purple-200 bg-purple-50 rounded-lg p-4 hover:bg-purple-100 cursor-pointer"
                    >
                      <div className="flex items-center">
                        {getIcon(action.icon, action.type)}
                        <div className="ml-4">
                          <h4 className="text-sm font-medium text-neutral-900">
                            {action.title}
                          </h4>
                          <p className="text-xs text-neutral-600 mt-1">
                            {action.description}
                          </p>
                          <div className="mt-2">
                            <span className="inline-block bg-white text-purple-700 text-xs px-2 py-1 rounded-full border border-purple-200">
                              Discount available
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            
          </>
        )}
      </CardContent>
    </Card>
  );
}
