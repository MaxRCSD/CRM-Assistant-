import { Customer } from "@/types";
import { Phone, Mail, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getInitials, formatDate } from "@/lib/utils";

interface CustomerHeaderProps {
  customer: Customer;
}

export default function CustomerHeader({ customer }: CustomerHeaderProps) {
  const getBadgeColor = (segment: string) => {
    switch (segment.toLowerCase()) {
      case 'premium':
        return 'bg-green-100 text-green-800';
      case 'vip':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  return (
    <div className="flex justify-between items-start bg-white p-6 rounded-lg shadow-sm">
      <div className="flex items-center">
        <div className="h-20 w-20 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-600 text-3xl font-semibold">
          {getInitials(customer.name)}
        </div>
        <div className="ml-4">
          <h2 className="text-3xl font-bold text-neutral-900 mb-2">{customer.name}</h2>
          <div className="flex items-center space-x-3 mb-2">
            <span className="bg-blue-50 text-blue-700 px-3 py-1.5 rounded-full font-medium">
              {customer.communicationPreference}
            </span>
            <span className="bg-purple-50 text-purple-700 px-3 py-1.5 rounded-full font-medium">
              {customer.accountType}
            </span>
          </div>
          <div className="flex items-center mt-1">
            <Badge 
              variant="outline" 
              className={`mr-2 ${getBadgeColor(customer.segment)}`}
            >
              {customer.segment}
            </Badge>
            <span className="text-sm text-neutral-500 mr-2">
              {customer.industry}
            </span>
            <span className="text-sm text-neutral-500">
              Customer since {formatDate(customer.customerSince)}
            </span>
          </div>
          <div className="flex items-center mt-2 text-sm">
            <Mail className="h-4 w-4 text-neutral-500 mr-1" />
            <span className="text-neutral-600">{customer.email}</span>
            {customer.phone && (
              <>
                <Phone className="h-4 w-4 text-neutral-500 ml-3 mr-1" />
                <span className="text-neutral-600">{customer.phone}</span>
              </>
            )}
          </div>
          <div className="flex flex-wrap mt-2 text-xs">
            <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded mr-2 mb-1">
              Comm. Pref: <span className="font-semibold">{customer.communicationPreference}</span>
            </span>
            <span className="bg-purple-50 text-purple-700 px-2 py-1 rounded mr-2 mb-1">
              Account: {customer.accountType}
            </span>
            <span className="bg-amber-50 text-amber-700 px-2 py-1 rounded mb-1">
              Payment: {customer.paymentMethod}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
