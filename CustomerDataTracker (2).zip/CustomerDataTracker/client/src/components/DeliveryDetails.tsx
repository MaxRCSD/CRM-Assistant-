
import { Order } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface DeliveryDetailsProps {
  order: Order;
}

export default function DeliveryDetails({ order }: DeliveryDetailsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Delivery Details</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-medium text-neutral-500">Collection Address</h4>
            <p className="mt-1 text-sm text-neutral-900">
              {order.collectionAddress?.line1}<br />
              {order.collectionAddress?.line2 && <>{order.collectionAddress.line2}<br /></>}
              {order.collectionAddress?.city}<br />
              {order.collectionAddress?.postcode}
            </p>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-neutral-500">Delivery Address</h4>
            <p className="mt-1 text-sm text-neutral-900">
              {order.deliveryAddress?.line1}<br />
              {order.deliveryAddress?.line2 && <>{order.deliveryAddress.line2}<br /></>}
              {order.deliveryAddress?.city}<br />
              {order.deliveryAddress?.postcode}
            </p>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-neutral-500">Special Instructions</h4>
            <p className="mt-1 text-sm text-neutral-900">
              {order.specialInstructions || 'None'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
