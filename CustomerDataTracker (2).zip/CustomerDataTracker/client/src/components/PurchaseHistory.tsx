import { Order } from "@/types";
import { formatCurrency, formatDate } from "@/lib/utils";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface PurchaseHistoryProps {
  orders: Order[];
}

export default function PurchaseHistory({ orders }: PurchaseHistoryProps) {
  // Sort orders by date (newest first)
  const sortedOrders = [...orders].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-900">Purchase History</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {sortedOrders.length === 0 ? (
            <div className="text-center py-4 text-neutral-500">
              No purchase history available
            </div>
          ) : (
            sortedOrders.slice(0, 4).map((order) => (
              <div 
                key={order.id} 
                className="flex items-center justify-between py-2 border-b border-neutral-100"
              >
                <div>
                  <div className="text-sm font-medium text-neutral-900">
                    Order #{order.id}
                  </div>
                  <div className="text-sm text-neutral-500">
                    {formatDate(order.date)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-neutral-900">
                    {formatCurrency(order.amount)}
                  </div>
                  <div className="text-xs text-neutral-500">
                    {order.vehicleSize} · {order.mileage} miles
                  </div>
                  <div className="text-xs text-neutral-500">
                    {order.handballing > 0 && `${order.handballing} min handballing · `}
                    {order.waitingTime > 0 && `${order.waitingTime} min waiting`}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        
        {orders.length > 4 && (
          <div className="mt-4 text-center">
            <span className="text-sm text-neutral-500">
              {orders.length - 4} more orders in history
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
