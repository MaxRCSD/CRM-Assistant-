import { ProductPreference, TopProduct } from "@/types";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface ProductPreferencesProps {
  preferences: ProductPreference[];
  topProducts: TopProduct[];
}

export default function ProductPreferences({ 
  preferences, 
  topProducts 
}: ProductPreferencesProps) {
  // Sort preferences by percentage (highest first)
  const sortedPreferences = [...preferences].sort((a, b) => b.percentage - a.percentage);

  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-900">Product Preferences</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {sortedPreferences.length === 0 ? (
            <div className="text-center py-2 text-neutral-500">
              No preference data available
            </div>
          ) : (
            sortedPreferences.map((preference) => (
              <div key={preference.id} className="flex items-center">
                <div className="w-2/3">
                  <div className="text-sm font-medium text-neutral-900">
                    {preference.category}
                  </div>
                </div>
                <div className="w-1/3">
                  <Progress value={preference.percentage} className="h-2" />
                  <div className="text-xs text-right mt-1 text-neutral-500">
                    {preference.percentage}%
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="mt-6">
          <h4 className="text-sm font-medium text-neutral-900 mb-2">Most Purchased Products</h4>
          <div className="space-y-2">
            {topProducts.length === 0 ? (
              <div className="text-sm text-neutral-500">
                No product data available
              </div>
            ) : (
              topProducts.map((product) => (
                <div key={product.id} className="text-sm text-neutral-700">
                  - {product.name}
                </div>
              ))
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
