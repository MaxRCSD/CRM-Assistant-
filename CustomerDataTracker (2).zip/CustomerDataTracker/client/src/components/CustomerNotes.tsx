import { Note } from "@/types";
import { formatDate } from "@/lib/utils";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface CustomerNotesProps {
  notes: Note[];
  customerId: number;
}

export default function CustomerNotes({ notes, customerId }: CustomerNotesProps) {
  // Sort notes by date (newest first)
  const sortedNotes = [...notes].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const getBadgeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'support':
        return 'bg-blue-100 text-blue-800';
      case 'sales':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-neutral-100 text-neutral-800';
    }
  };

  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-900">Customer Notes</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {sortedNotes.length === 0 ? (
            <div className="text-center py-2 text-neutral-500">
              No notes available
            </div>
          ) : (
            sortedNotes.map((note) => (
              <div 
                key={note.id} 
                className="border-b border-neutral-100 pb-4"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <div className="text-sm font-medium text-neutral-900">
                      {note.author}
                    </div>
                    <div className="text-xs text-neutral-500">
                      {formatDate(note.date)}
                    </div>
                  </div>
                  <Badge 
                    variant="outline" 
                    className={getBadgeColor(note.type)}
                  >
                    {note.type}
                  </Badge>
                </div>
                <div className="mt-2 text-sm text-neutral-700">
                  {note.content}
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
