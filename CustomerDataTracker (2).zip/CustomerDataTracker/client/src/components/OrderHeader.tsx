
import { Order } from "@/types";
import { Package, MapPin, Calendar, User } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";

interface OrderHeaderProps {
  order: Order;
}

export default function OrderHeader({ order }: OrderHeaderProps) {
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in progress':
        return 'bg-blue-100 text-blue-800';
      case 'pending':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-neutral-100 text-neutral-800';
    }
  };

  return (
    <div className="flex justify-between items-start bg-white p-6 rounded-lg shadow-sm">
      <div className="flex-1">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-neutral-900">Order #{order.id}</h2>
          <Badge 
            variant="outline" 
            className={`${getStatusColor(order.status)}`}
          >
            {order.status}
          </Badge>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center space-x-2">
            <Package className="h-4 w-4 text-neutral-500" />
            <span className="text-sm text-neutral-600">{order.vehicleType}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <MapPin className="h-4 w-4 text-neutral-500" />
            <span className="text-sm text-neutral-600">{order.mileage} miles</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-neutral-500" />
            <span className="text-sm text-neutral-600">{formatDate(order.date)}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <User className="h-4 w-4 text-neutral-500" />
            <span className="text-sm text-neutral-600">{order.customerName}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
