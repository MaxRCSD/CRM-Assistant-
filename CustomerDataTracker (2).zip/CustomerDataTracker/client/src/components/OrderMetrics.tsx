
import { Order } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import { formatCurrency } from "@/lib/utils";

interface OrderMetricsProps {
  order: Order;
}

export default function OrderMetrics({ order }: OrderMetricsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card>
        <CardContent className="p-5">
          <h3 className="text-sm font-medium text-neutral-500">Total Cost</h3>
          <div className="mt-1">
            <span className="text-2xl font-semibold text-neutral-900">
              {formatCurrency(order.totalCost)}
            </span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-5">
          <h3 className="text-sm font-medium text-neutral-500">Waiting Time</h3>
          <div className="mt-1">
            <span className="text-2xl font-semibold text-neutral-900">
              {order.waitingTime} mins
            </span>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-5">
          <h3 className="text-sm font-medium text-neutral-500">Handballing</h3>
          <div className="mt-1">
            <span className="text-2xl font-semibold text-neutral-900">
              {order.handballing ? 'Yes' : 'No'}
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
